public class Villager extends Player{
    public Villager(String name) {
        super(name);
    }
    public void set(){}
    @Override
    public String getRole() {
        return "Villager";
    }
}
